# Aarix V2.1 — build guide

This package contains the Flutter source plus an Android project skeleton.

## Recommended build
1. Open the folder in a Flutter-capable builder.
2. Run `flutter pub get`.
3. Run `flutter build apk --release`.
4. The APK will be under `build/app/outputs/flutter-apk/app-release.apk`.

## Important
V2.1 is a local functional foundation. Authentication, posts, likes/comments and profile editing are local-only in this build. Real accounts, cloud media, push notifications and production private messaging require a backend.
